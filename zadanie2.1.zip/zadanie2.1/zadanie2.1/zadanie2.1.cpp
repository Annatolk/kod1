﻿#include <iostream>
#include <vector>
#include <random>

int main() {
    setlocale(LC_ALL, "RU");
    int size;
    std::cout << "Введите размер массива: ";
    std::cin >> size;

    std::vector<int> array(size);

    // Заполнение массива случайными числами от -100 до 100
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dis(-100, 100);

    for (int i = 0; i < size; ++i) {
        array[i] = dis(gen);
    }

    // Вывод содержимого массива
    std::cout << "Массив случайных чисел: ";
    for (int num : array) {
        std::cout << num << " ";
    }
    std::cout << std::endl;

    // Вычисление суммы отрицательных чисел
    int sum_negative = 0;
    for (int num : array) {
        if (num < 0) {
            sum_negative += num;
        }
    }

    std::cout << "Сумма отрицательных чисел: " << sum_negative << std::endl;

    return 0;
}